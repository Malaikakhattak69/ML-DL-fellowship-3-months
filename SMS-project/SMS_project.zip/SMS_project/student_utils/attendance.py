def attendance_percentage(attended, total):
    return (attended / total) * 100
